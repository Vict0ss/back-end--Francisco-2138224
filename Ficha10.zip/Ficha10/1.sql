CREATE DATABASE ficha10;
use ficha10;